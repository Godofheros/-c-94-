const firebaseConfig = {
    apiKey: "AIzaSyCNm3Vi6Gpkygyx1ybn871-zrN1zGZRQxw",
    authDomain: "kwitter-6bcf6.firebaseapp.com",
    databaseURL: "https://kwitter-6bcf6-default-rtdb.firebaseio.com",
    projectId: "kwitter-6bcf6",
    storageBucket: "kwitter-6bcf6.appspot.com",
    messagingSenderId: "607443739612",
    appId: "1:607443739612:web:f5737341876872a8fce519",
    measurementId: "G-WFHVRDY2FV"
  };
  
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  //const analytics = getAnalytics(app);
//ADD YOUR FIREBASE LINKS
function addUser()
{
    user_name = document.getElementById("user_name").value
    firebase.database().ref("/").child(user_name).update({
    purpose : "adding user"    
    })
}
